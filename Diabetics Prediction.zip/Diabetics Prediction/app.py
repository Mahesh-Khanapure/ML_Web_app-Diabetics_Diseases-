from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('Diabetics.pkl', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    # Get the user input
    prediction_class = ""
    prediction_message = ""
    Age = int(request.form.get("1"))
    GLUCOSE = float(request.form.get("2"))
    BLOOD_PRESSURE = float(request.form.get("3"))
    Skin = float(request.form.get("4"))
    insulin = float(request.form.get("5"))
    BMI = float(request.form.get("6"))
    DiabetesPedigreeFunction = float(request.form.get("7"))
    
#test_input =[148,72,35,0,33.6,0.627,50]#output=1
#test_input=[85,66,29,0,26.6,0.351,31]#output=0
   
    user_input = [ GLUCOSE, BLOOD_PRESSURE, Skin, insulin, BMI, DiabetesPedigreeFunction, Age]

    # Make a prediction using the loaded model
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    print(prediction)

    if prediction[0] == 1:
        prediction_class = "green"
        prediction_message = "The patient does not have Diabetics Disease."
    else:
        prediction_class = "red"
        prediction_message = "The patient has Diabetics Disease."

    return render_template("result.html", prediction_message=prediction_message, prediction_class=prediction_class,
                           user_input=user_input)


if __name__ == "__main__":
    app.run(debug=True, port=5112)